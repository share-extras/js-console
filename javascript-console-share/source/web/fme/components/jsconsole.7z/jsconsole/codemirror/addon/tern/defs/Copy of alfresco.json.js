(function() {
var def = {
  "!name": "alfresco",
  "ScriptNode": {
      "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-ScriptNode.html",
      "!doc": "In JavaScript code various parts of the underlying system can be conveniently exposed as objects of type ScriptNode. For example, the companyhome, userhome, document, space, and person objects are best represented as objects of type ScriptNode. The ScriptNode API provides access to properties and methods for manipulating this type of object.",
      "getName": {
        "!type": "fn() -> string",
        "!url": "org.alfresco.repo.jscript.ScriptNode.getName()",
        "!doc": "@return Helper to return the 'name' property for the node"
      },
      "getType": {
        "!type": "fn() -> string",
        "!url": "https://developer.mozilla.org/en-US/docs/JavaScript/Reference/Global_Objects/JSON/stringify",
        "!doc": "Convert a value to JSON, optionally replacing values if a replacer function is specified, or optionally including only the specified properties if a replacer array is specified."
      },
      "name1": {
          "!type": "string",
          "!url": "org.alfresco.repo.jscript.ScriptNode#name",
          "!doc": "A writable property that contains the name of the node. Do not forget to save after change the property..."
      }
   },
  "search": {
    "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-Search.html",
    "!doc": "The Search API provides direct access to repository level search results and Saved Search results through the search root scope object. Local searches can be performed using the ScriptNode APIs childByNamePath and childByXPath. Like the various node objects, the search object is part of the root scope.",
    "findNode": {
      "!type": "fn(nodeRef: string) -> +ScriptNode",
      "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
      "!doc": "This method returns a single ScriptNode as specified by the string form of the NodeRef for that node, null is returned if the search failed."
    },
    "luceneSearch": {
        "!type": "fn(query: string) -> [+ScriptNode]",
        "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-luceneSearch.html",
        "!doc": "This method performs a full-text search and returns an array of ScriptNode objects that were found by the Alfresco repository search."
    },
    "luceneSearch": {
        "!type": "fn(query: string, store: string) -> [+ScriptNode]",
        "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-luceneSearch.html",
        "!doc": "This method performs a lucene search in the given store, e.g. <code>workspace://SpacesStore</code> and returns an array of ScriptNode objects that were found by the Alfresco repository search."
    },
    "getSearchSubsystem": {
        "!type": "fn() -> string",
        "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
        "!doc": "This method returns a single ScriptNode as specified by the string form of the NodeRef for that node, null is returned if the search failed."
      }
  },
  "session": {
      "!url": " http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-Session.html",
      "!doc": "A root level session object is provided to access the current logged in user session ticket as a string value.",
      "getTicket": {
        "!type": "fn() -> string",
        "!url": "org.alfresco.repo.jscript.Session.getTicket()",
        "!doc": "Gets the current authentication ticket"
      }
  },
  "siteservice": {
      "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-SiteserviceObject.html",
      "!doc": "The siteservice object provides methods to create sites, list sites in the repository, list roles that can be assigned to members of a site, and get sites for given names.",
      "findSites": {
        "!type": "fn(filter: string, sitePresetFilter: string, size: string) -> +ScriptNode",
        "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
        "!doc": "This method returns a single ScriptNode as specified by the string form of the NodeRef for that node, null is returned if the search failed."
      },
      "luceneSearch": {
          "!type": "fn(query: string) -> [+ScriptNode]",
          "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-luceneSearch.html",
          "!doc": "This method performs a full-text search and returns an array of ScriptNode objects that were found by the Alfresco repository search."
      },
      "luceneSearch": {
          "!type": "fn(query: string, store: string) -> [+ScriptNode]",
          "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-luceneSearch.html",
          "!doc": "This method performs a lucene search in the given store, e.g. <code>workspace://SpacesStore</code> and returns an array of ScriptNode objects that were found by the Alfresco repository search."
      },
      "getSearchSubsystem": {
          "!type": "fn() -> string",
          "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
          "!doc": "This method returns a single ScriptNode as specified by the string form of the NodeRef for that node, null is returned if the search failed."
        }
    },
    "site ": {
        "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-Site.html",
        "!doc": "The site object represents a share site",
        "sitePreset": {
          "!type": "string",
          "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-Site.html",
          "!doc": "A read-only name of the site preset used to create the site"
        },
        "shortName": {
            "!type": "fn(query: string) -> [+ScriptNode]",
            "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-Site.html",
            "!doc": "A read-only unique short name identifying the site"
        },
        "title": {
            "!type": "string",
            "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-luceneSearch.html",
            "!doc": "The displayable title of the site"
        },
        "description": {
            "!type": "string",
            "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
            "!doc": "The displayable description of the site"
        },
        "isPublic": {
            "!type": "boolean",
            "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
            "!doc": "The displayable description of the site"
        },
        "visibility": {
            "!type": "string",
            "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
            "!doc": "The visibility of the site (<code>PUBLIC_SITE</code>, MODERATED_SITE, PRIVATE_SITE)"
        },
        "description": {
            "!type": "string",
            "!url": "http://docs.alfresco.com/4.1/topic/com.alfresco.enterprise.doc/references/API-JS-findNode.html",
            "!doc": "The displayable description of the site"
        }
      }
 }
CodeMirror.tern.addDef(def);
})();